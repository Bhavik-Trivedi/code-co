<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-lg-4">
				<div class="copyright_div wow fadeIn" data-wow-duration="1s" data-wow-delay="2s">
					© Wail Nourildean Al Rifaie 2019. All Rights Reserved.
				</div>
			</div>
			<div class="col-md-6 col-lg-8 wow fadeIn" data-wow-duration="1s" data-wow-delay="2s">
				<div class="design_credits">
					Design & Developed By Code & Co
				</div>
			</div>
		</div>
	</div>	
</footer>