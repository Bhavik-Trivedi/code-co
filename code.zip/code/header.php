<header class="my_menu">
	<div class="top_header">
		<div class="container">
			<div class="row align-items-center">
				<div class="top_header_inner_content wow fadeIn" data-wow-duration="1s">
					<div class="th_email th_contact_method">
						<a href="mailto:wnrifaie@yahoo.com">
							<div class="th_email_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_email_icon.png"></div>
							<div class="th_contact_method_detail th_email_id">wnrifaie@yahoo.com</div>
						</a>
					</div>
					<div class="th_skype th_contact_method">
						<a href="skype:wail nourlildean_al rifae">
							<div class="th_skype_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_skype_icon.png"></div>
							<div class="th_contact_method_detail th_skype_id">wail nourlildean_al rifae</div>
						</a>
					</div>
					<div class="th_mobile th_contact_method">
						<a href="tel:+971 53 831 5673">
							<div class="th_mobile_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_mobile_icon.png"></div>
							<div class="th_contact_method_detail th_mobile_no">+971 53 831 5673</div>
						</a>
					</div>
					<div class="th_whatsapp th_contact_method">
						<a href="https://api.whatsapp.com/send?phone=+971 53 831 5673" target="_blank">
							<div class="th_whatsapp_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_whatsapp_icon.png"></div>
							<div class="th_contact_method_detail th_whatsapp_no">+971 53 831 5673</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-expand-lg fixed-top">
		<div class="container p-0">
		  	<a class="navbar-brand wow fadeIn" data-wow-duration="1s" data-wow-delay="1s" href="<?php echo $base_url; ?>">Wail Nourildean Al-Rifaie</a>
		  	<button class="navbar-toggler wow fadeIn" data-wow-duration="1s" data-wow-delay="1.5s" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    	<span class="navbar-toggler-icon"></span>
		  	</button>
		  	<div class="collapse navbar-collapse justify-content-end wow fadeIn" data-wow-duration="1s" data-wow-delay="1.5s" id="collapsibleNavbar">
		    	<ul class="navbar-nav">
		      		<li class="nav-item">
		        		<a class="nav-link active" href="javascript:void(0)">Home</a><span class="divider">|</span>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="javascript:void(0)">About Me</a><span class="divider">|</span>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="javascript:void(0)">My Expertise</a><span class="divider">|</span>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="javascript:void(0)">My Impact</a><span class="divider">|</span>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="javascript:void(0)">Published Books</a><span class="divider">|</span>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="javascript:void(0)">Contact</a>
		      		</li>
		    	</ul>
		  	</div>
	  	</div>  
	</nav>
</header>