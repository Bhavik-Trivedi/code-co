<?php include("common.php"); $page='home'?>
<!DOCTYPE html>
<html>
<head>
	<title>Prof Wail - Homepage</title>
	<?php include("meta-content.php");?>
	<?php include("css-scripts.php");?>	
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>css/header-footer.css">
</head>
<body>
	
	<!-- WEBSITE HEADER STARTS HERE -->
		<?php include("header.php");?>
	<!-- WEBSITE HEADER ENDS HERE -->

	<!-- PAGE CONTENT STARTS HERE -->

		<section class="section1 mysection">
			<div class="container">
				<div class="row">
					<div class="col-sm-8 order-2 order-md-1">
						<div class="section1_left_data_div">
							<div class="section1_left_data_div_title wow fadeInUp" data-wow-duration="2s" data-wow-delay="1.5s">
								Welcome,<br>
								I am Dr. Wail Nourildean Al-Rifaie.
							</div>
							<div class="section1_left_data_div_desc wow fadeIn" data-wow-duration="2s" data-wow-delay="2s">
								I am a research scholar and I have successfully conducted extensive experiments & published numerous journals on Engineering & Construction solutions. I'm one of the World's leading authority in the Field of Ferrocement.
							</div>
							<div class="consult_now_div wow fadeIn" data-wow-duration="2s" data-wow-delay="2.5s">
								<a href="javascript:void(0)">Consult Now</a>
							</div>
						</div>
					</div>
					<div class="col-sm-4 order-1 order-md-2">
						<div class="prof_img_div d-inline-block d-sm-none wow fadeIn" data-wow-duration="2s" data-wow-delay="1.2s">
							<img src="<?php echo $base_url; ?>images/prof_wail_photo.png" class="img-fluid">
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section2 mysection">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-sm-4 left_div wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1s">
						<div class="section2_left_title">
							My Specializations
						</div>
						<div class="section2_right_title">
							Lorem ipsum dolor sit amet, consectetur
							adipisicing elit, sed do eiusmod tempor
							incididunt ut labore et dolore magna aliqua.
						</div>
					</div>
					<div class="col-sm-8 pr-md-0 dbl wow fadeIn" data-wow-duration="1s"  data-wow-offset="100" data-wow-delay="1s">
						<div class="specialization_slider_div">
							<div class="specialization-swiper swiper-container container-fluid">
							    <div class="swiper-wrapper row align-items-center">
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content wow fadeInRight" data-wow-duration="2s" data-wow-offset="100" data-wow-delay="1.1s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/scientist-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Scientist
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content wow fadeInRight" data-wow-duration="2s" data-wow-offset="100" data-wow-delay="1.2s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/innovator-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Innovator
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content nbr wow fadeInRight" data-wow-duration="2s" data-wow-offset="100" data-wow-delay="1.3s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/teacher-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Teacher
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content wow fadeInRight" data-wow-duration="2s" data-wow-delay="1.4s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/consultant-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Consultant
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content wow fadeInRight" data-wow-duration="2s" data-wow-delay="1.5s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/speaker-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Speaker
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content nbr wow fadeInRight" data-wow-duration="2s" data-wow-delay="1.6s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/environmentalist-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Environmentalist
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							        <div class="swiper-slide col-12 col-md-4">
							        	<div class="swiper-slide-content nbr mb-0 wow fadeInRight" data-wow-duration="2s" data-wow-delay="1.7s">
							        		<div class="specialization-title">
							        			<span class="specialization-title-icon">
							        				<img src="<?php echo $base_url; ?>images/humanitarian-icon.png" class="img-fluid">
							        			</span>
							        			<span class="specialization-title-text">
							        				Humanitarian
							        			</span>
							        		</div>
							        		<div class="specialization-desc">
							        			Ut enim ad minim veniam, quis nostrud ipsum dolor sit
							        		</div>
							        		<a href="javascript:void(0)" class="specialization-readmore">Read More</a>
							        	</div>
							        </div>
							    </div>
							</div>
							<div class="specialization_swiper_button_next d-block d-md-none wow fadeIn" data-wow-duration="2s" data-wow-delay="1.8s">
								<img src="<?php echo $base_url;?>images/swiper_right_arrow.svg" class="img-responsive">
							</div>
							<div class="specialization_swiper_button_prev d-block d-md-none disabled wow fadeIn" data-wow-duration="2s" data-wow-delay="1.8s">
								<img src="<?php echo $base_url;?>images/swiper_left_arrow.svg" class="img-responsive">
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section3 mysection">
			<div class="container">
				<div class="section3_div">
					<div class="section3_title wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="1s">
						How Can I Help
					</div>
					<div class="hcih_slider_div">
						<div class="hcih-swiper swiper-container">
						    <div class="swiper-wrapper">
						        <div class="swiper-slide">
						        	<div class="hcih-slide-content wow fadeIn" data-wow-duration="2s" data-wow-delay="2s">
						        		<div class="hcih_img_div">
						        			<img src="<?php echo $base_url; ?>images/hcih_slider_1.png" class="img-fluid">
						        		</div>
						        		<div class="hcih_title">
						        			Companies/Corporates
						        		</div>
						        		<div class="hcih_desc">
						        			<ul>
						        				<li>Consultation & expertise on Ferrocement implementation and application.</li>
						        				<li>Expertise to bring down carbon footprint.</li>
						        				<li>Consultation for implementing eco-friendly and energy efficient solutions.</li>
						        			</ul>
						        		</div>
						        		<div class="inquire_now_div">
						        			<a href="javascript:void(0)">Inquire Now</a>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="hcih-slide-content wow fadeIn" data-wow-duration="2s" data-wow-delay="2.1s">
						        		<div class="hcih_img_div">
						        			<img src="<?php echo $base_url; ?>images/hcih_slider_2.png" class="img-fluid">
						        		</div>
						        		<div class="hcih_title">
						        			Students
						        		</div>
						        		<div class="hcih_desc">
						        			<ul>
						        				<li>Research Guidance.</li>
						        				<li>Consultation and Advisor.</li>
						        			</ul>
						        		</div>
						        		<div class="inquire_now_div">
						        			<a href="javascript:void(0)">Inquire Now</a>
						        		</div>
						        	</div>
						        </div>
						        <div class="swiper-slide">
						        	<div class="hcih-slide-content wow fadeIn" data-wow-duration="2s" data-wow-delay="2.2s">
						        		<div class="hcih_img_div">
						        			<img src="<?php echo $base_url; ?>images/hcih_slider_3.png" class="img-fluid">
						        		</div>
						        		<div class="hcih_title">
						        			Organizations
						        		</div>
						        		<div class="hcih_desc">
						        			<ul>
						        				<li>Influential talks and lectures on ‘ferrocement as sustainable construction materials’.</li>
						        				<li>Presenting successful Workshops & Seminars on ‘Producing Sustainable Construction Materials: Ferrocement’.</li>
						        			</ul>
						        		</div>
						        		<div class="inquire_now_div">
						        			<a href="javascript:void(0)">Inquire Now</a>
						        		</div>
						        	</div>
						        </div>
						    </div>
						    <div class="hcih_swiper_button_next d-block d-md-none wow fadeIn" data-wow-duration="2s" data-wow-delay="2.4s">
						    	<img src="<?php echo $base_url;?>images/swiper_right_arrow.svg" class="img-responsive">
						    </div>
						    <div class="hcih_swiper_button_prev d-block d-md-none disabled wow fadeIn" data-wow-duration="2s" data-wow-delay="2.4s">
						    	<img src="<?php echo $base_url;?>images/swiper_left_arrow.svg" class="img-responsive">
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section4 mysection">
			<div class="container">
				<div class="row">
					<div class="col-sm-7">
						<div class="section4_title wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1s">
							My Impact
						</div>
						<div class="section4_subtitle wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.2s">
							Introducing Nano Ferrocement
						</div>
						<div class="section4_desc wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1s">
							It is some combination of metal and cement mortar. It is, in fact steel reinforced concrete, all ferrocement 
							call be said to be reinforced concrete, but all types of reinforced concrete are not ferrocement.
						</div>
						<div class="section4_benefits">
							<div class="benefits_title wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.4s">Benefits</div>
							<div class="benefits_details">
								<div class="row">
									<div class="benefits_1 col-sm-5 pr-md-0 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.8s">
										<div class="container-fluid">
											<div class="row">
												<div class="benefits_icon col-2 p-0">
													<img src="<?php echo $base_url; ?>images/benefit_icon_1.png" class="img-fluid">
												</div>
												<div class="benefit_desc col-10 p-0">
													Easy to introduce the insulation material in the system.
												</div>
											</div>
										</div>
									</div>
									<div class="benefits_1 col-sm-7 p-md-0 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="2s">
										<div class="container-fluid">
											<div class="row">
												<div class="benefits_icon col-2 p-0">
													<img src="<?php echo $base_url; ?>images/benefit_icon_2.png" class="img-fluid">
												</div>
												<div class="benefit_desc col-10 p-0">
													The system of multi - cell structural panels can be used for roofing, slabs, walls, floors and the insulation materials will be accommodated by cells.
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="view_all_benefits">
								<a href="javascript:void(0)" class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="2.2s">View All Benefits</a>
							</div>
						</div>
					</div>
					<div class="col-sm-5">
						<div class="molecules_img_div wow fadeInRight" data-wow-duration="2s" data-wow-delay="1.4s">
							<img src="<?php echo $base_url; ?>images/molecules.png" class="img-fluid">
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section5 mysection">
			<div class="container">
				<div class="row">
					<div class="col-12 p-0">
						<div class="section5_title wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1s">
							Wail Nourildean Al-Rifaie
						</div>
					</div>
					<div class="col-md-3 p-0">
						<div class="contact_details">
							<div class="contact_title wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.2s">
								Contact
							</div>
							<div class="th_email th_contact_method wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.4s">
								<a href="mailto:wnrifaie@yahoo.com">
									<div class="th_email_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_email_icon.png"></div>
									<div class="th_contact_method_detail th_email_id">wnrifaie@yahoo.com</div>
								</a>
							</div>
							<div class="th_whatsapp th_contact_method wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.6s">
								<a href="https://api.whatsapp.com/send?phone=+971 53 831 5673" target="_blank">
									<div class="th_whatsapp_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_whatsapp_icon.png"></div>
									<div class="th_contact_method_detail th_whatsapp_no">+971 53 831 5673</div>
								</a>
							</div>
							<div class="th_skype th_contact_method wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.8s">
								<a href="skype:wail nourlildean_al rifae">
									<div class="th_skype_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_skype_icon.png"></div>
									<div class="th_contact_method_detail th_skype_id">wail nourlildean_al rifae</div>
								</a>
							</div>
							<div class="th_mobile th_contact_method wow fadeInLeft" data-wow-duration="2s" data-wow-delay="2s">
								<a href="tel:+971 53 831 5673">
									<div class="th_mobile_icon th_contact_method_icon"><img src="<?php echo $base_url; ?>images/th_mobile_icon.png"></div>
									<div class="th_contact_method_detail th_mobile_no">+971 53 831 5673</div>
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-9 dbl wow fadeIn" data-wow-duration="1s" data-wow-delay="1s">
						<div class="git_form_div">
							<div class="contact_title wow fadeInRight" data-wow-duration="2s" data-wow-delay="1.2s">
								Get in Touch with Me
							</div>
							<div class="git_form wow fadeIn" data-wow-duration="2s" data-wow-delay="2s">
								<form class="contactform" method="POST" role="form" id="contactform" novalidate="">
									<div class="container-fluid">
										<div class="row">
											<div class="col-12 col-sm-4">
												<div class="form-group">
											        <div class="group">
											            <input type="text" id="name" name="name" class="form_fields form-control" placeholder="" autocomplete="off" required=""">
											            <label>Name</label>
											        </div>
										        </div>
											</div>
											<div class="col-12 col-sm-4">
												<div class="form-group">
											        <div class="group">
											            <input type="text" id="email" name="email" class="form_fields form-control" placeholder="" autocomplete="off" required=""">
											            <label>Email</label>
											        </div>
											    </div>
											</div>
											<div class="col-12 col-sm-4">
												<div class="form-group">
											        <div class="group">
											            <input type="text" id="subject" name="subject" class="form_fields form-control" placeholder="" autocomplete="off" required=""">
											            <label>Subject</label>
											        </div>
											    </div>
											</div>
											<div class="col-12 col-sm-12">
												<div class="otherdetailscomments">
											        <div class="form-group">
											            <div class="group textarea_group">
											                <textarea name="message" class="form_fields textarea_field form-control" rows="10" id="message" autocomplete="off" required="" aria-required="true"></textarea>
											                <label>Message</label>
											            </div>
											        </div>
											    </div>
											</div>
											<div class="col-12">
												<div class="form-group send_btn_div mb-md-0">
													<button type="submit" class="btn btn-primary send_btn">Send Message</button>
												</div>
											</div>
									    </div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

	<!-- PAGE CONTENT ENDS HERE -->

	<!-- WEBSITE FOOTER STARTS HERE -->
		<?php include("footer.php");?>
	<!-- WEBSITE FOOTER ENDS HERE -->

	<?php include("js-scripts.php");?>

</body>
</html>