
	$(document).ready(function(){

		new WOW().init();

		var targetOffset = 10;

		var $w = $(window).scroll(function(){
		    if ( $w.scrollTop() > targetOffset ) {
		        $(".navbar").addClass("minimized");
		    } else {
		      	$(".navbar").removeClass("minimized");
		    }
	    });

		var swiper = new Swiper('.hcih-swiper.swiper-container', {
			slidesPerView: 3,
			spaceBetween: 30,
			simulateTouch: false,
	      	breakpoints: {
		        992: {
		        	simulateTouch: true,
		          	slidesPerView: 1,
		          	navigation: {
		          	  	nextEl: '.hcih_swiper_button_next',
		          	  	prevEl: '.hcih_swiper_button_prev',
		          	},
		        },
	      	}
		});
		
		if($(window).width()<768){
			var swiper = new Swiper('.specialization-swiper.swiper-container', {
				slidesPerView: 1,
				spaceBetween: 0,
				simulateTouch: true,
		      	breakpoints: {
			        992: {
						navigation: {
						  	nextEl: '.specialization_swiper_button_next',
						  	prevEl: '.specialization_swiper_button_prev',
						},
					},
				}
			});
			
		}

	    function validateEmail($email) {
	     var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	     return emailReg.test( $email );
	    }

		$('#contactform').submit(function(e){
		    e.preventDefault();
		    var name = $(this).find('#name').val();
		    var email_id = $(this).find('#email').val();
		    var subject = $(this).find('#subject').val();
		    var message = $(this).find('#message').val();
		    
		    if(name === ''){
		        $(this).find('#name').focus();
		        $(this).find('#name').addClass('validateerror');
		        return;
		    }
		    else{
		        $(this).find('#name').removeClass('validateerror');
		    }		    
		    
		    if(email_id === '' || (!validateEmail(email_id)) ){
		        $(this).find('#email').focus();
		        $(this).find('#email').addClass('validateerror');
		        return;
		    }
		    else{
		        $(this).find('#email').removeClass('validateerror');
		    }
		    
		    if(subject === ''){
		        $(this).find('#subject').focus();
		        $(this).find('#subject').addClass('validateerror');
		        return;
		    }
		    else{
		        $(this).find('#subject').removeClass('validateerror');
		    }
		    
		    if(message === ''){
		        $(this).find('#message').focus();
		        $(this).find('#message').addClass('validateerror');
		        return;
		    }
		    else{
		        $(this).find('#message').removeClass('validateerror');
		    }
		    
		    var data = $(this).serialize();
		    $("#contactform .send_btn").prop('disabled',true);
		    $.ajax({
		        url:'mail.php',
    	        type:'post',
    	        data:data,
    	        success:function(result){
    	        	alert("Form Submitted !!!");
    	        	location.reload();
    	        }
		    });
		});

	});
